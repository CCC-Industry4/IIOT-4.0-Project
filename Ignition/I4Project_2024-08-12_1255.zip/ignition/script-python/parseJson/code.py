import json

def func(input):
	dict = json.loads(input)
	return dict